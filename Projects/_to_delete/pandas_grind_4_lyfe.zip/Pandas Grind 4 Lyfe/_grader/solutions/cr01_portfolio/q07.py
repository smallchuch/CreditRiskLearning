# ============================================================================================
# cr01_portfolio  |  Q07  |  ★★★ challenge
#
# Broker concentration: among live loans written by a broker (`broker_id` not missing), the
# **HHI** of balance across brokers = sum over brokers of (balance share in %)^2. Round to 1
# dp.
#
# Return 1 column(s), in the order the question gives them. Expected 1 row(s).
# Row order does not matter.
# Put your final answer in `result` (DataFrame, Series, list, dict or a single value).
# ============================================================================================

# %% setup (runs every time - each file must stand on its own)
import os, sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__) if '__file__' in globals() else os.getcwd(), '..', '..')))
import numpy as np
import pandas as pd
from grind import load

snap = load('loan_monthly_snapshot')
loan = load('loan')

# %% your answer
live = snap[(snap['snapshot_date'] == '2025-12-31') & (snap['loan_status'] != 'Closed')]

m = live[['loan_id', 'closing_balance']].merge(loan[['loan_id', 'broker_id']], on='loan_id').dropna(subset=['broker_id'])
share = 100 * m.groupby('broker_id')['closing_balance'].sum() / m['closing_balance'].sum()
result = round((share ** 2).sum(), 1)
