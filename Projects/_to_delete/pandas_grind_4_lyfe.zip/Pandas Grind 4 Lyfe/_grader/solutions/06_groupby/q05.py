# ============================================================================================
# 06_groupby  |  Q05  |  ★★ core
#
# Loans per origination year and `rate_type`. Return `year`, `rate_type`, `loans`; sorted by
# `year`, `rate_type`.
#
# Return 3 column(s), in the order the question gives them. Expected 16 row(s).
# Sort the output as described.
# Put your final answer in `result` (DataFrame, Series, list, dict or a single value).
# ============================================================================================

# %% setup (runs every time - each file must stand on its own)
import os, sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__) if '__file__' in globals() else os.getcwd(), '..', '..')))
import numpy as np
import pandas as pd
from grind import load

loan = load('loan')

# %% your answer
result = loan.groupby([loan['origination_date'].dt.year.rename('year'), 'rate_type']).size()
