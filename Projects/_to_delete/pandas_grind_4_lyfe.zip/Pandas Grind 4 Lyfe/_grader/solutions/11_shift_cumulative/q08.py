# ============================================================================================
# 11_shift_cumulative  |  Q08  |  ★★★ challenge
#
# For loans that ever reached 30+ days past due, the `months_on_book` at which they
# **first** did. Return the average, rounded to 1 dp.
#
# Return 1 column(s), in the order the question gives them. Expected 1 row(s).
# Row order does not matter.
# Put your final answer in `result` (DataFrame, Series, list, dict or a single value).
# ============================================================================================

# %% setup (runs every time - each file must stand on its own)
import os, sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__) if '__file__' in globals() else os.getcwd(), '..', '..')))
import numpy as np
import pandas as pd
from grind import load

snap = load('loan_monthly_snapshot')

# %% your answer
s = snap[snap['days_past_due'] >= 30]
result = round(s.groupby('loan_id')['months_on_book'].min().mean(), 1)
