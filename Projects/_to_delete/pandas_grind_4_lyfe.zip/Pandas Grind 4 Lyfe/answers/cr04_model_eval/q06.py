# ============================================================================================
# cr04_model_eval  |  Q06  |  ★★★ challenge
#
# Capture rate: what percentage of all bads fall in the **worst 20%** of loans by bureau
# score (lowest scores; use `rank(method='first')` so exactly 20% of loans are picked)?
# Round to 2 dp.
#
# Return 1 column(s), in the order the question gives them. Expected 1 row(s).
# Row order does not matter.
# Put your final answer in `result` (DataFrame, Series, list, dict or a single value).
# ============================================================================================

# %% setup (runs every time - each file must stand on its own)
import os, sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__) if '__file__' in globals() else os.getcwd(), '..', '..')))
import numpy as np
import pandas as pd
from grind import load

snap = load('loan_monthly_snapshot')
applicant = load('application_applicant')
bureau = load('credit_bureau_report')
loan = load('loan')

# %% your answer
result = None
